# Replaying the synthetic outputs

This is a public reader projection of a private synthetic source proof. The six data files, score.py and results.json are unchanged source bytes. The values and outcomes are invented; running this program does not measure an AI model, enterprise performance or causal value.

Use Python 3.12 or later. From the extracted reader folder:

```text
python -B score.py --data data --output replay-results.json
python -B score.py --data data --cutoff 2026-10-02T17:00:00Z --q 7/10
```

Without --cutoff, score.py computes the recorded suite of four cutoffs and four consequence settings. Compare replay-results.json with the supplied results.json as parsed JSON, allowing platform-specific line endings. Preserve the supplied inputs and original results; write any replay output to a new file.

Check this projection’s SHA256SUMS before replay. PROVENANCE maps each retained source payload to its original hash. No fixture construction or original author-test execution is provided by this reader package; those depend on omitted private source documents.

Generated NOT_ESTABLISHED and NOT_GRANTED fields are retained source-era metadata. They do not provide live permissions or supersede the recorded review history. The original proof review does not establish empirical input validity, public-package integrity or reader understanding.

Use is governed by the included LICENSE.
